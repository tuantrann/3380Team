import React from 'react';

export const PageNotFoundBox = (props) => {

    return (
        <div>
            Page Not Found
        </div>
    )
}
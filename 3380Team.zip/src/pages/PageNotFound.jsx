import React, { useState } from 'react';
import { PageNotFoundBox } from '../components/pageNotFound/pageNotFound.jsx';

export const PageNotFound = (props) => {
  return (
    <PageNotFoundBox />
  );
}
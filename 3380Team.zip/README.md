HOW TO INSTALL

make sure you have install npm and node

git clone https://github.com/tuantrann/3380Team.git

cd 3380Team

npm install

then open 2 terminal inside the 3380 Team folder

do npm start

then npm run dev
